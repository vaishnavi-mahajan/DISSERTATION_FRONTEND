var Chart = require("chart.js");
import Neo4j from "./neo4j";
import logout from "./logout";
import moment from "moment";

// containers
const $main = $("main");
const $canvas = $("#canvas");

const neo4j = new Neo4j();

var projectBudgetChart;
var allBudgetChart;
var table;

$(document.body).ready(function () {
  // testBcrypt();

  //Load User Name
  if (sessionStorage.getItem("userId")) {
    $("#user-name").html(sessionStorage.getItem("userId"));
    $("#user-role").html(sessionStorage.getItem("role"));
  } else {
    window.location.href = "./unauthorized";
  }

  //Summary Events
  $("#sidebar-summary").addClass("active");
  displayTaskPhaseChart();
  displayTaskStatusChart();
  loadUsers();
  loadAuditTrail();

  $("#sidebar-planning-item").on("click", () => {
    $("#section-summary").css("display", "none");
    $("#section-planning-item").css("display", "block");
    $("#sidebar-planning-item").addClass("active");
    $("#sidebar-summary").removeClass("active");
    loadPlanningItems();
  });

  $("#sidebar-summary").on("click", () => {
    $("#section-summary").css("display", "block");
    $("#section-planning-item").css("display", "none");
    $("#sidebar-planning-item").removeClass("active");
    $("#sidebar-summary").addClass("active");
    displayTaskPhaseChart();
    displayTaskStatusChart();
  });

  $("#selectPlanningItem").on("change", () => {
    //Toggle
    $("#section-planning-content").css("display", "block");
    const selectedVal = $(this).find(":selected").val();
    loadPlanningItemCharts(selectedVal);
    displayProjectBudgetChart(selectedVal);
    loadProjectDetails(selectedVal);
    displayAllBudgetChart(selectedVal);
    CalculateProjectLaunchDate(selectedVal);

   
  });

  $("#lnk-logout").on("click", () => {
    logout(sessionStorage.getItem("userId"));
  });
});

const displayTaskPhaseChart = async () => {
  const query = `MATCH (n:Item_Name) RETURN n.Task_Phase as phase, count(*) as count`;
  const res = await neo4j.get(query);

  const phases = res.results[0].data.map((item) => {
    return item.row[0];
  });

  const counts = res.results[0].data.map((item) => {
    return item.row[1];
  });

  var ctx = $("#canvas-taskphase");
  var myChart = new Chart(ctx, {
    type: "doughnut",
    data: {
      labels: phases,
      datasets: [
        {
          label: "# of Votes",
          data: counts,
          backgroundColor: [
            "rgb(255, 99, 132)",
            "rgb(54, 162, 235)",
            "rgb(255, 205, 86)",
            "rgba(255, 99, 132, 0.2)",
            "rgba(54, 162, 235, 0.2)",
            "rgba(255, 206, 86, 0.2)",
            "rgba(75, 192, 192, 0.2)",
            "rgba(153, 102, 255, 0.2)",
            "rgba(255, 159, 64, 0.2)",
          ],
          hoverOffset: 4,
        },
      ],
    },
    options: {
      responsive: true,
      //  maintainAspectRatio: false,

      //cutoutPercentage: 70,
      scales: {
        y: {
          beginAtZero: true,
        },
      },
    },
  });
};

const displayTaskStatusChart = async () => {
  const query = "MATCH (n:Item_Name) RETURN n.Task_Status, count(*)";
  const res = await neo4j.get(query);

  const phases = res.results[0].data.map((item) => {
    return item.row[0];
  });

  const counts = res.results[0].data.map((item) => {
    return item.row[1];
  });
  console.log("phases", phases);
  console.log("counts", counts);

  var ctx = $("#canvas-taskstatus");
  var myChart = new Chart(ctx, {
    type: "bar",
    data: {
      labels: phases,
      datasets: [
        {
          label: [],
          data: counts,
          backgroundColor: [
            "rgba(255, 99, 132, 0.2)",
            "rgba(54, 162, 235, 0.2)",
            "rgb(255, 99, 132)",
            "rgb(54, 162, 235)",
            "rgb(255, 205, 86)",
            "rgba(255, 206, 86, 0.2)",
            "rgba(75, 192, 192, 0.2)",
            "rgba(153, 102, 255, 0.2)",
            "rgba(255, 159, 64, 0.2)",
          ],
          hoverOffset: 4,
        },
      ],
    },
    options: {
      legend: {
        display: false,
      },
      responsive: true,
      //  maintainAspectRatio: false,

      //cutoutPercentage: 70,
      scales: {
        y: {
          beginAtZero: true,
        },
      },
    },
  });
};

const loadPlanningItems = async () => {
  const query = `MATCH (n:Item_Name) RETURN distinct n.Planning_Item_ID,n.Planning_Item_Name`;
  const res = await neo4j.get(query);
  res.results[0].data.forEach((item) => {
    $("#selectPlanningItem").append(
      $("<option />").val(item.row[0]).text(item.row[1])
    );
  });
};

const loadUsers = async () => {
  const query = `MATCH (n:User) where n.active="1" RETURN distinct n.userId,n.role`;
  const res = await neo4j.get(query);
  res.results[0].data.forEach((item) => {
    $("#user-list").append(
      ` <div class="row border-bottom p-2 ${
        item.row[0] == sessionStorage.getItem("userId")
          ? "text-success"
          : "text-success"
      }">
      <div class="col-sm">${item.row[0]}</div>
      <div class="col-sm">${item.row[1]}</div>
  </div>`
    );
  });
};

const loadPlanningItemCharts = async (selectedItem) => {
  const query = `MATCH (n:Item_Name {Planning_Item_ID:'${selectedItem}'}) RETURN n.Task_Phase`;
  const res = await neo4j.get(query);

  const task_phase = res.results[0].data[0].row[0];
  //console.log("task_phase", task_phase);
  const green_completed = `<div class="c100 p100 green center">
  <span>Completed</span>
  <div class="slice">
      <div class="bar"></div>
      <div class="fill"></div>
  </div>
</div>`;

  const orange_inprogress = `<div class="c100 p100 orange center">
<span>In Progress</span>
<div class="slice">
    <div class="bar"></div>
    <div class="fill"></div>
</div>
</div>`;

  const blue_not_started = `<div class="c100 p100 center">
<span>Not Started</span>
<div class="slice">
    <div class="bar"></div>
    <div class="fill"></div>
</div>
</div>`;

  if (task_phase.toLowerCase().includes("planning")) {
    $("#card-body-planning div").html(orange_inprogress);
    $("#card-body-requirements div").html(blue_not_started);
    $("#card-body-design div").html(blue_not_started);
    $("#card-body-development div").html(blue_not_started);
    $("#card-body-testing div").html(blue_not_started);
    $("#card-body-not-deployed div").html(blue_not_started);
    $("#card-body-deployed div").html(blue_not_started);
    $("#card-body-integration div").html(blue_not_started);
    $("#card-body-operation div").html(blue_not_started);
  } else if (task_phase.toLowerCase().includes("requirement")) {
    $("#card-body-planning div").html(green_completed);
    $("#card-body-requirements div").html(orange_inprogress);
    $("#card-body-design div").html(blue_not_started);
    $("#card-body-development div").html(blue_not_started);
    $("#card-body-testing div").html(blue_not_started);
    $("#card-body-not-deployed div").html(blue_not_started);
    $("#card-body-deployed div").html(blue_not_started);
    $("#card-body-integration div").html(blue_not_started);
    $("#card-body-operation div").html(blue_not_started);
  } else if (task_phase.toLowerCase().includes("design")) {
    $("#card-body-planning div").html(green_completed);
    $("#card-body-requirements div").html(green_completed);
    $("#card-body-design div").html(orange_inprogress);
    $("#card-body-development div").html(blue_not_started);
    $("#card-body-testing div").html(blue_not_started);
    $("#card-body-not-deployed div").html(blue_not_started);
    $("#card-body-deployed div").html(blue_not_started);
    $("#card-body-integration div").html(blue_not_started);
    $("#card-body-operation div").html(blue_not_started);
  } else if (task_phase.toLowerCase().includes("development")) {
    $("#card-body-planning div").html(green_completed);
    $("#card-body-requirements div").html(green_completed);
    $("#card-body-design div").html(green_completed);
    $("#card-body-development div").html(orange_inprogress);
    $("#card-body-testing div").html(blue_not_started);
    $("#card-body-not-deployed div").html(blue_not_started);
    $("#card-body-deployed div").html(blue_not_started);
    $("#card-body-integration div").html(blue_not_started);
    $("#card-body-operation div").html(blue_not_started);
  } else if (task_phase.toLowerCase().includes("testing")) {
    $("#card-body-planning div").html(green_completed);
    $("#card-body-requirements div").html(green_completed);
    $("#card-body-design div").html(green_completed);
    $("#card-body-development div").html(green_completed);
    $("#card-body-testing div").html(orange_inprogress);
    $("#card-body-not-deployed div").html(blue_not_started);
    $("#card-body-deployed div").html(blue_not_started);
    $("#card-body-integration div").html(blue_not_started);
    $("#card-body-operation div").html(blue_not_started);
  } else if (task_phase.toLowerCase().includes("not deployed")) {
    $("#card-body-planning div").html(green_completed);
    $("#card-body-requirements div").html(green_completed);
    $("#card-body-design div").html(green_completed);
    $("#card-body-development div").html(green_completed);
    $("#card-body-testing div").html(green_completed);
    $("#card-body-not-deployed div").html(orange_inprogress);
    $("#card-body-deployed div").html(blue_not_started);
    $("#card-body-integration div").html(green_completed);
    $("#card-body-operation div").html(green_completed);
  } else if (task_phase.toLowerCase().includes("deployed")) {
    $("#card-body-planning div").html(green_completed);
    $("#card-body-requirements div").html(green_completed);
    $("#card-body-design div").html(green_completed);
    $("#card-body-development div").html(green_completed);
    $("#card-body-testing div").html(green_completed);
    $("#card-body-not-deployed div").html(green_completed);
    $("#card-body-deployed div").html(orange_inprogress);
    $("#card-body-integration div").html(green_completed);
    $("#card-body-operation div").html(green_completed);
  } else if (task_phase.toLowerCase().includes("integration")) {
    $("#card-body-planning div").html(green_completed);
    $("#card-body-requirements div").html(green_completed);
    $("#card-body-design div").html(green_completed);
    $("#card-body-development div").html(green_completed);
    $("#card-body-testing div").html(green_completed);
    $("#card-body-not-deployed div").html(blue_not_started);
    $("#card-body-deployed div").html(blue_not_started);
    $("#card-body-integration div").html(orange_inprogress);
    $("#card-body-operation div").html(blue_not_started);
  } else if (task_phase.toLowerCase().includes("operation")) {
    $("#card-body-planning div").html(green_completed);
    $("#card-body-requirements div").html(green_completed);
    $("#card-body-design div").html(green_completed);
    $("#card-body-development div").html(green_completed);
    $("#card-body-testing div").html(green_completed);
    $("#card-body-not-deployed div").html(blue_not_started);
    $("#card-body-deployed div").html(blue_not_started);
    $("#card-body-integration div").html(green_completed);
    $("#card-body-operation div").html(orange_inprogress);
  } else {
    $("#card-body-planning div").html(blue_not_started);
    $("#card-body-requirements div").html(blue_not_started);
    $("#card-body-design div").html(blue_not_started);
    $("#card-body-development div").html(blue_not_started);
    $("#card-body-testing div").html(blue_not_started);
    $("#card-body-not-deployed div").html(blue_not_started);
    $("#card-body-deployed div").html(blue_not_started);
    $("#card-body-integration div").html(blue_not_started);
    $("#card-body-operation div").html(blue_not_started);
  }
};

const displayProjectBudgetChart = async (selectedItem) => {
  const query = `MATCH (n:Item_Name {Planning_Item_ID:'${selectedItem}'}) RETURN n.Allocated_Budget, n.Allocated_Budget_Currency, n.Total_Budget`;
  const res = await neo4j.get(query);
  //console.log(query);
  const Allocated_Budget = res.results[0].data[0].row[0];
  const Allocated_Currency = res.results[0].data[0].row[1];
  const Total_Budget = res.results[0].data[0].row[2];
  const Max_Scale = Math.max(
    parseInt(Allocated_Budget),
    parseInt(Total_Budget)
  );
  // console.log("Max_Scale", Max_Scale);
  const DATA_COUNT = 7;
  const NUMBER_CFG = { count: DATA_COUNT, min: 0, max: Max_Scale };

  if (projectBudgetChart) {
    //   console.log("destroying..");
    projectBudgetChart.destroy();
    //  console.log("destroyed..");
  }

  var ctxNew = $("#canvas-project-budget");
  projectBudgetChart = new Chart(ctxNew, {
    type: "bar",
    data: {
      datasets: [
        {
          label: `Allocated Budget : ${Allocated_Budget} (${Allocated_Currency})`,
          data: [Allocated_Budget],
          backgroundColor: [
            "rgba(255, 99, 132, 0.2)",
            "rgba(255, 159, 64, 0.2)",
          ],

          borderWidth: 0,
        },
        {
          label: `Total Budget : ${Total_Budget} (${Allocated_Currency})`,
          data: [Total_Budget],
          backgroundColor: [
            "rgba(255, 159, 64, 0.2)",
            "rgba(255, 205, 86, 0.2)",
          ],

          borderWidth: 0,
        },
      ],
    },
    options: {
      responsive: true,
      scales: {
        yAxes: [
          {
            ticks: {
              beginAtZero: true,
              maxTicksLimit: 5,
            },
          },
        ],
      },
    },
  });
};

//Load Project Details

const loadProjectDetails = async (selectedItem) => {
  const query = `MATCH (n:Item_Name {Planning_Item_ID:'${selectedItem}'}) RETURN n.Planning_Item_Parent_Name, n.Planning_Item_Name, n.Hierarchy_Definition_ID,n.Hierarchy_Definition_Node_ID,n.Team_Size,n.Plan_Start_Date `;
  const res = await neo4j.get(query);
  // console.log(query);
  const Planning_Item_Parent_Name = res.results[0].data[0].row[0];
  const Planning_Item_Name = res.results[0].data[0].row[1];
  const Hierarchy_Definition_ID = res.results[0].data[0].row[2];
  const Hierarchy_Definition_Node_ID = res.results[0].data[0].row[3];
  const Team_Size = res.results[0].data[0].row[4];
  const Plan_Start_Date = res.results[0].data[0].row[5];

  $("#row-planning-item-parent").html(Planning_Item_Parent_Name);
  $("#row-planning-item").html(Planning_Item_Name);
  $("#row-planning-item-id").html(selectedItem);
  $("#row-heirarchy-definition-id").html(Hierarchy_Definition_ID);
  $("#row-heirarchy-definition-node").html(Hierarchy_Definition_Node_ID);
  $("#row-team-size").html(Team_Size);
  $("#row-start-date").html(Plan_Start_Date);
  loadPlanningItemsOfParent(
    Planning_Item_Parent_Name,
    Hierarchy_Definition_Node_ID
  );
};

const displayAllBudgetChart = async (selectedItem) => {
  const query = `MATCH (n:Item_Name {Planning_Item_ID:'${selectedItem}'}) RETURN n.Allocated_Budget, n.Allocated_Budget_Currency, n.Total_Budget, n.Reserved_Budget, n.Rolledup_Budget, n.Available_Budget `;
  const res = await neo4j.get(query);
  //console.log(query);
  const Allocated_Budget = res.results[0].data[0].row[0];
  const Allocated_Currency = res.results[0].data[0].row[1];
  const Total_Budget = res.results[0].data[0].row[2];
  const Reserved_Budget = res.results[0].data[0].row[3];
  const Rolledup_Budget = res.results[0].data[0].row[4];
  const Available_Budget = res.results[0].data[0].row[4];

  const Max_Scale = Math.max(
    parseInt(Allocated_Budget),
    parseInt(Total_Budget),
    parseInt(Reserved_Budget),
    parseInt(Rolledup_Budget),
    parseInt(Available_Budget)
  );
  // console.log("Max_Scale", Max_Scale);
  const DATA_COUNT = 7;
  const NUMBER_CFG = { count: DATA_COUNT, min: 0, max: Max_Scale };

  if (allBudgetChart) {
    allBudgetChart.destroy();
  }

  var ctxNew = $("#canvas-all-budget");
  allBudgetChart = new Chart(ctxNew, {
    type: "bar",
    data: {
      datasets: [
        {
          label: `Allocated Budget : ${Allocated_Budget} (${Allocated_Currency})`,
          data: [Allocated_Budget],
          backgroundColor: ["rgba(255, 99, 132, 0.2)"],

          borderWidth: 0,
        },
        {
          label: `Total Budget : ${Total_Budget} (${Allocated_Currency})`,
          data: [Total_Budget],
          backgroundColor: ["rgba(255, 159, 64, 0.2)"],

          borderWidth: 0,
        },
        {
          label: `Reserved Budget : ${Reserved_Budget} (${Allocated_Currency})`,
          data: [Reserved_Budget],
          backgroundColor: ["rgba(255, 205, 86, 0.2)"],

          borderWidth: 0,
        },
        {
          label: `Rolledup Budget : ${Rolledup_Budget} (${Allocated_Currency})`,
          data: [Rolledup_Budget],
          backgroundColor: ["rgba(54, 162, 235, 0.2)"],

          borderWidth: 0,
        },
        {
          label: `Available Budget : ${Available_Budget} (${Allocated_Currency})`,
          data: [Available_Budget],
          backgroundColor: ["rgba(153, 102, 255, 0.2)"],

          borderWidth: 0,
        },
      ],
    },
    options: {
      responsive: true,
      scales: {
        yAxes: [
          {
            ticks: {
              beginAtZero: true,
              maxTicksLimit: 5,
            },
          },
        ],
      },
    },
  });
};

const loadPlanningItemsOfParent = async (
  Planning_Item_Parent_Name,
  Hierarchy_Definition_Node_ID
) => {
  const query = `MATCH (n:Item_Name {Hierarchy_Definition_Node_ID:'${Hierarchy_Definition_Node_ID}'}) RETURN collect(n.Planning_Item_Name) `;
  const res = await neo4j.get(query);
  console.log("query", query);
  console.log(res);

  // const planning_item_names = res.results[0].data[0].row.join(" ,");

  $("#planning-item-parent-name").html(Planning_Item_Parent_Name);
  // $("#planning-items").html(
  //   `<span title="${planning_item_names}">${
  //     planning_item_names.length > 500
  //       ? planning_item_names.substring(0, 500) + "..."
  //       : planning_item_names
  //   }</span`
  // );

  res.results[0].data[0].row[0].map((item) => {
    $("#table-parent-item tbody").append(`
    <tr>
      <td>${item}</td>
    </tr>
    `);
  });

  $("#table-parent-item").DataTable({
    info: false,
    lengthChange: false,
    pageLength: 5,
    destroy: true,
  });
};

const loadAuditTrail = async () => {
  const query = `MATCH (n:Audit_Log) RETURN n.user,n.node,n.action,n.timestamp order by n.timestamp desc limit 50`;
  const res = await neo4j.get(query);
  console.log("query-audit", query);
  console.log("res-audit", res);

  res.results[0].data.map((item) => {
    console.log("item", item);
    const css_class = item.row[2].toLowerCase().includes("create")
      ? "action-create"
      : item.row[2].toLowerCase().includes("update")
      ? "action-update"
      : "action-delete";

    $("#table-audit-trail tbody").append(`
     <tr>
       <td>${item.row[0]}</td>
       <td class="${css_class}">${item.row[2]}</td>
       <td>${item.row[1]}</td>
       <td>${item.row[3]}</td>
     </tr>
     `);
  });

  $("#table-audit-trail").DataTable({
    info: false,
    lengthChange: false,
    pageLength: 5,
  });
};

const CalculateProjectLaunchDate = async (selectedItem) => {
  const query = `MATCH (n:Item_Name {Planning_Item_ID:'${selectedItem}'}) RETURN n.Total_Budget, n.Team_Size, n.Planning_Level_Number,n.Plan_Start_Date `;
  const res = await neo4j.get(query);
  const Total_Budget = parseInt(res.results[0].data[0].row[0]);
  const Team_Size = parseInt(res.results[0].data[0].row[1]);
  const Planning_Level_Number = parseInt(res.results[0].data[0].row[2]);
  const Plan_Start_Date = res.results[0].data[0].row[3];
  var projectedDate =Plan_Start_Date;
  const neo4jdateFormat = projectedDate.includes('-') ?  'dd-MM-YYYY' : 'dd/MM/YYYY';

  switch (Total_Budget) {
    case 100:
      switch (Team_Size) {
        case 8:          
          projectedDate = moment(Plan_Start_Date,neo4jdateFormat).add(11 - Planning_Level_Number, "months").format("dddd, MMMM Do YYYY");
          break;
        case 10:
          
          projectedDate = moment(Plan_Start_Date,neo4jdateFormat).add(9 - Planning_Level_Number, "months").format("dddd, MMMM Do YYYY");
          break;
        case 6:
          
          projectedDate = moment(Plan_Start_Date,neo4jdateFormat).add(15 - Planning_Level_Number, "months").format("dddd, MMMM Do YYYY");
          break;
        default:
          break;
      }
      break;
    case 1500:
      switch (Team_Size) {
        case 8:
          
          projectedDate = moment(Plan_Start_Date,neo4jdateFormat).add(13 - Planning_Level_Number, "months").format("dddd, MMMM Do YYYY");
          break;
        case 10:
          
          projectedDate = moment(Plan_Start_Date,neo4jdateFormat).add(11 - Planning_Level_Number, "months").format("dddd, MMMM Do YYYY");
          break;
        case 6:
          
          projectedDate = moment(Plan_Start_Date,neo4jdateFormat).add(13 - Planning_Level_Number, "months").format("dddd, MMMM Do YYYY");
          break;
        default:
          break;
      }
      break;
    case 2000:
      switch (Team_Size) {
        case 8:
          
          projectedDate = moment(Plan_Start_Date,neo4jdateFormat).add(15 - Planning_Level_Number, "months").format("dddd, MMMM Do YYYY");
          break;
        case 10:
          
          projectedDate = moment(Plan_Start_Date,neo4jdateFormat).add(13 - Planning_Level_Number, "months").format("dddd, MMMM Do YYYY");
          break;
        case 6:          
          projectedDate = moment(Plan_Start_Date,neo4jdateFormat).add(17 - Planning_Level_Number, "months").format("dddd, MMMM Do YYYY");
          break;
        default:
          break;
      }
      break;
    default:
      break;
  }

  $("#projected-launch").html(projectedDate);

};
