import Neo4j from './neo4j';
import moment from 'moment';
const neo4j = new Neo4j();

const CreateAuditLogs = async (user_id, node_name , action) => {
    const query = `CREATE (n:Audit_Log {user : "${user_id}", node : "${node_name}", action : "${action}", timestamp : "${moment().format("YYYY-MM-DD HH:mm:ss")}"})`;
    const res = await neo4j.update(query);
    console.log("res.status", res.status);
    if (!res.data.errors.length) {
        console.log("Audit log created");
    }    
}

export default CreateAuditLogs;