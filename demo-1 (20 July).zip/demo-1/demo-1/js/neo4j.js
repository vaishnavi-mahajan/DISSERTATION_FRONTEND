import axios from "axios";

export default class Neo4j {
  constructor() {
    console.log("Hello from neo4js");

    this.Neo4jHost = "localhost";
    this.Neo4jPort = 7474;
    this.Neo4jUser = "neo4j";
    this.Neo4jPass = "admin#123";
    this.Neo4jDb = "neo4j";

    this.axios = axios.create({
      baseURL: this.baseURL(),
      "Access-Control-Allow-Origin": "*",
      headers: {
        ...this.authHeaders(),
      },
    });
  }
  baseURL() {
    return `http://${this.Neo4jHost}:${this.Neo4jPort}/db/${this.Neo4jDb}`;
  }
  authHeaders() {
    return {
      Authorization: `Basic ${btoa(
        `${this.Neo4jUser}:${this.Neo4jPass}`
      )}`,
    };
  }

  async get(query, params = {}, fetchMode = ["row", "graph"]) {
    const res = await this.axios.post(
      "/tx/commit",
      {
        statements: [
          {
            statement: query,
            parameters: params,
            resultDataContents: fetchMode,
          },
        ],
      },
      {
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      }
    );
    return res.data;
  }

  //Update Property Here

  async update(query, params = {}, fetchMode = ["row", "graph"]) {
    const res = await this.axios.post(
      "/tx/commit",
      {
        statements: [
          {
            statement: query,
            parameters: params,
            resultDataContents: fetchMode,
          },
        ],
      },
      {
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      }
    );
    console.log("res : ", res);
    return res;
  }
}
