import Neo4j from "./neo4j";
const neo4j = new Neo4j();
var bcrypt = require("bcryptjs");
import moment from 'moment';

$(document.body).ready(function () {
  sessionStorage.clear();
  $("#btn-login").on("click", () => {
    onLogin();
  });
});

const onLogin = async () => {
  $("#error").html("");
  const user = $("#username").val();
  const password = $("#password").val();

  console.log(password);

  if (!user) {
    $("#error").html("Please enter user name");
    return;
  }

  if (!password) {
    $("#error").html("Please enter password");
    return;
  }

  const query = `MATCH (n:User) where n.userId='${user}' return n `;
  console.log("query", query);
  const res = await neo4j.get(query);

  if (res.results[0].data.length) {
    const passwordInDb = res.results[0].data[0].row[0].password;
    
    const compare = await bcrypt.compare(password, passwordInDb);
    console.log("pid", passwordInDb);
    console.log("password", password);
    console.log("compare", compare);

    if (compare) {
      sessionStorage.setItem("userId", res.results[0].data[0].row[0].userId);
      sessionStorage.setItem("role", res.results[0].data[0].row[0].role);
      updateLoginTimeStamp(res.results[0].data[0].row[0].userId);
      window.location.href = "./dashboard.html";
    } else {
      $("#error").html("Failed to login. Invalid password.");
    }

  } else {
    $("#error").html("Failed to login. Invalid user/password.");
  }

  console.log(res);
};


const updateLoginTimeStamp = async (userId) => {
  console.log("hi from login")
  const query = `MATCH (n:User) where n.userId='${userId}' SET n.active="1", n.last_login="${moment().format("YYYY-MM-DD HH:mm")}" return n `;
  console.log(query);
  const res = await neo4j.get(query);  
}