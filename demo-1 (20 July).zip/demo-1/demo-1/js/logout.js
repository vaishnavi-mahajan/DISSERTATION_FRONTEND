import Neo4j from "./neo4j";
import moment from "moment";
const neo4j = new Neo4j();

const logout = async (userId) => {
  console.log("hi from logout");
  const query = `MATCH (n:User) where n.userId='${userId}' SET n.active="0", n.last_logout="${moment().format(
    "YYYY-MM-DD HH:mm"
  )}" return n `;
  console.log(query);
  const res = await neo4j.get(query);
  window.location.href="./index.html";
};

export default logout;
