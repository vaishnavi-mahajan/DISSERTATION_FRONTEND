import Neo4j from "./neo4j";
import TreeGraph from "./tree-graph";
import { v4 as uuidv4 } from "uuid";
import CreateAuditLogs from "./audit-trail";
import moment from "moment";
import logout from "./logout";

// containers
const $main = $("main");
const $canvas = $("#canvas");

const Manager_Editable = [
  "Task_Status",
  "Allocated_Budget",
  "Total_Expenses",
  "Reserved_Budget",
  "Team_Size",
  "Task_Cost",
  "Rolledup_Budget",
];

const Developer_Editable = [
  "Planning_Item_Owner_User_Name",
  "Allocated_Budget_Currency",
  "Planning_Level_Type",
  "Planning_Item_Name",
  "Planning_Item_Created_By_User_Name",
  "Level_3_Planning_Item_Name",
  "Level_4_Planning_Item_Name",
  "Level_2_Planning_Item_Name",
  "Level_1_Planning_Item_Name",
  "Currency_cd",
  "Planning_Item_Type",
  "Plan_Start_Date",
  "Planning_Item_Number",
  "Planning_Item_Parent_Name",
  "Total_Invoiced",
  "Load_Datetime",
  "Task_Phase",
  "Planning_Level_Number",
  "Total_Committed", 
  
  "Available_Budget",
  "Planning_Item_Description",
  "name",
  "Planning_Item_Path"
];

const neo4j = new Neo4j();

const NODES = {
  Planning_Item_Parent_Name: "Planning_Item_Parent_Name",
  Item_Name: "Item_Name",
};

const graph = new TreeGraph("#canvas");
// add node clicked event listner
graph.addEventListener("node.clicked", (e) => {
  UpdatePropertyTable(e);
  /*const props = e.target.$node.node;
  console.log("props", props);
  $("#table-properties tbody").html(
    Object.keys(props).map((prop) =>
      $("<tr />", {
        //class: "list-group-item",
      }).append(
        $("<td />", {
          class: "",
        }).append(
          prop
        )
      ).append(
        $("<td />", {
          class: "",
        }).append(
          $("<input />", {
            class: "form-control form-control-sm disabled",
            title: props[prop],
            value: props[prop],
            readonly : prop != "Team_Size",
            id : "txt_" + prop
          })
        )
      )
    )
  );
  $("#collapse-properties").collapse("show");*/
});

async function UpdatePropertyTable(e) {
  const role = sessionStorage.getItem("role").toLowerCase();
  const Planning_Item_ID = e.target.$node.node.Planning_Item_ID;
  const query = `MATCH (n:Item_Name {Planning_Item_ID:"${Planning_Item_ID}"}) RETURN n`;
  console.log("Queryy", query);
  const res = await neo4j.get(query);
  const props = res.results[0].data[0].row[0];
  $("#table-properties tbody").html(
    Object.keys(props).map((prop) =>
      $("<tr />", {
        //class: "list-group-item",
      })
        .append(
          $("<td />", {
            class: "",
          }).append(prop)
        )
        .append(
          $("<td />", {
            class: "",
          }).append(
            $("<input />", {
              class: "form-control form-control-sm disabled",
              title: props[prop],
              value: props[prop],
              // readonly: (role == "manager" && !Manager_Editable.includes(prop)) || (role == "developer" && !Developer_Editable.includes(prop)) || true,
              readonly:
                role == "manager"
                  ? !Manager_Editable.includes(prop)
                  : role == "developer"
                  ? !Developer_Editable.includes(prop)
                  : true,
              id: "txt_" + prop,
            })
          )
        )
    )
  );
  $("#collapse-properties").collapse("show");
}

$("#toolbar-expand-all").on("click", function () {
  graph.expandAllNode();
});

$(document.body).ready(function () {
  if (sessionStorage.getItem("userId")) {
    $("#user-name").html(sessionStorage.getItem("userId"));
    $("#user-role").html(sessionStorage.getItem("role"));
  } else {
    window.location.href = "./unauthorized";
  }

  if (sessionStorage.getItem("role").toLocaleLowerCase() == "developer") {
    $("#btn-delete-property").addClass("btn-secondary");
    $("#btn-delete-property").attr("disabled", "disabled");
    $("#btn-add-node").attr("disabled", "disabled");
  }

  if (sessionStorage.getItem("role").toLocaleLowerCase() == "customer") {
    $("#btn-save-property,#btn-delete-property").addClass("btn-secondary");
    $("#btn-save-property,#btn-delete-property").attr("disabled", "disabled");
    $("#btn-add-node").attr("disabled", "disabled");
  }

  $("#lnk-logout").on("click", () => {
    logout(sessionStorage.getItem("userId"));
  });

  showNodeTypes();
  showAllNodeTypes();
  drawTree();
});

async function showAllNodeTypes() {
  const query = `MATCH (n) WHERE EXISTS(n.Planning_Level_Type) RETURN DISTINCT "node" as entity, n.Planning_Level_Type AS Planning_Level_Type LIMIT 25 UNION ALL MATCH ()-[r]-() WHERE EXISTS(r.Planning_Level_Type) RETURN DISTINCT "relationship" AS entity, r.Planning_Level_Type AS Planning_Level_Type`;

  const res = await neo4j.get(query);
  $("#node-colors").append(
    res.results[0].data.map((e) =>
      $("<li />", {
        class: "list-group-item",
      }).append(
        $("<div />", {
          class: "input-group",
        }).append([
          $("<div />", {
            class: "input-group-prepend",
            title: e.row[1],
          }).append(
            $("<div />", { class: "input-group-text" }).html(
              `${
                e.row[1].length > 10
                  ? `${e.row[1].substring(0, 10)}...`
                  : e.row[1]
              }:- &nbsp;`
            )
          ),
          $("<input />", { class: "form-control color-picker", id: e.row[1] }),
          $("<div />", { class: "input-group-append" }).append(
            $("<div />", { class: "input-group-text color-shower" }).html(
              `&nbsp;&nbsp;`
            )
          ),
        ])
      )
    )
  );
  $(".color-picker").colorpicker();
  $(".color-picker").on("colorpickerChange", function (event) {
    $(event.target)
      .siblings(".input-group-append")
      .find(".color-shower")
      .css("background-color", event.color.toString());
    setTimeout(() => {
      graph.loopThroughAllNodes(
        graph.updateNodeBackgroud,
        getColorOptions(),
        "Planning_Level_Type"
      );
    }, 500);
  });
}

function getColorOptions() {
  const hasColor = {};
  $(".color-picker").each(function (i, e) {
    if (e.value) {
      hasColor[e.id] = e.value;
    }
  });
  return hasColor;
}

async function showNodeTypes() {
  const query = `MATCH (n) where not n:User and not n:Audit_Log RETURN distinct labels(n)`;
  const res = await neo4j.get(query, {}, ["row"]);
  const rows = res.results[0].data;
  $("#node-types").html([
    $("<span />", {
      class: "badge badge-success mb-2 mr-2 p-2",
    })
      .text("All")
      .on("click", (e) => drawTree("All")),
    ...rows.map((item) =>
      $("<span />", {
        class: "badge badge-success mb-2 mr-2 p-2",
      })
        .text(item.row[0])
        .on("click", (e) => drawTree(item.row[0]))
    ),
  ]);
  $("#collapse-nodes").collapse("show");
}

async function drawTree(type = "All") {
  // query with mapping to relations
  // const query = `MATCH (a:Person)-[:ACTED_IN]->(m:Movie) WITH  a, collect(m) AS movies RETURN a, movies LIMIT $limit`;
  let query = "";
  if (type == "All") {
    query = `MATCH (a)-[]->(m) WITH  a, collect(m) AS movies RETURN a, movies`;
  } else {
    query = `MATCH (a: ${type}) RETURN a`;
  }
  // params
  const params = {
    // limit: 25
  };

  let data = {};

  const hasColor = getColorOptions();

  // query neo4j database and fetch the data
  try {
    data = await neo4j.get(query, params);
  } catch (err) {
    console.log(err);
    throw new Error(`Something went wrong!.`);
  }

  if (data.errors.length) {
    throw new Error(`${data.errors[0].message}`);
  }

  const rows = data.results[0].data;

  // rander tree graph with new data
  graph.render({
    data: rows.map((i) => ({
      name: i.row[0].name,
      node: i.row[0],
      color: hasColor[i.row[0].Planning_Level_Type] || null,
      children: (i.row[1] || []).map((c) => ({
        name: c.name,
        node: c,
        color: hasColor[c.Planning_Level_Type] || null,
      })),
    })),
  });
}

$("#search-form").submit(handleSearchSubmit);

function handleSearchSubmit(e) {
  e.preventDefault();

  const searchTerm = $("#search-input").val().toLowerCase();
  console.log("search term", searchTerm);
  if (searchTerm) {
    $("div.node-details").each(function () {
      if ($(this).html().toLowerCase() == (searchTerm)) {
        if (!$(this).parent("div").hasClass("search-text")) {
          $(this).parent("div").addClass("search-text");
          $(this).scroll();
        }
      } else {
        if ($(this).parent("div").hasClass("search-text")) {
          $(this).parent("div").removeClass("search-text");
        }
      }
    });

   // $(`div.node-details:contains("${searchTerm}")`).css("color", "red");
    //graph.loopThroughAllNodes(graph.toggleHighLight, searchTerm);
  }
}

$("#btn-save-property").on("click", () => {
  UpdateProperties();
});

$("#btn-delete-property").on("click", () => {
  $("#delete-modal").modal("toggle");
});

$("#btn-confirm-delete").on("click", () => {
  $("#delete-modal").modal("toggle");
  DeleteProperties();
});

$("#btn-add-node").on("click", () => {
  console.log("hello from add!");
  $("#add-modal").modal("toggle");
  loadParentNames();
  $("#txt_add_Planning_Item_Created_By_User_Name").val(
    sessionStorage.getItem("userId")
  );
  $("#txt_add_Planning_Item_ID").val(uuidv4());
});

$("#btn-save-node").on("click", () => {
  AddNode();
});

async function UpdateProperties() {
  const Planning_Item_ID = $("#txt_Planning_Item_ID").val();
  const name = $("#txt_name").val();
  const Team_Size = $("#txt_Team_Size").val();
  const whereClause = GenerateWhereClause();
  console.log("where", whereClause);
  const query = `MATCH (n:Item_Name {Planning_Item_ID:"${Planning_Item_ID}"}) SET ${whereClause} , n.Planning_Item_Last_Modified_By_User_Name="${sessionStorage.getItem(
    "userId"
  )}",
  n.Planning_Item_Last_Modified__Datetime="${moment().format(
    "YYYY-MM-DD HH:mm"
  )}"  RETURN n`;

  const res = await neo4j.update(query);
  console.log("res.status", res.status);
  if (!res.data.errors.length) {
    $("#alert-modal .modal-body").html("Properties updated successfully!");
    $("#alert-modal").modal("toggle");
    showNodeTypes();
    showAllNodeTypes();
    drawTree();
    CreateAuditLogs(sessionStorage.getItem("userId"), name, "Updated Node");
  }
}

function GenerateWhereClause() {
  var itemArray = [];
  if (sessionStorage.getItem("role").toLowerCase() == "manager") {
    itemArray = Manager_Editable;
  } else {
    itemArray = Developer_Editable;
  }
  var whereClause = "";

  itemArray.forEach((item) => {
    const itemVal = $("#txt_" + item).val();

    if (itemVal.toLowerCase() == "nan") {
      whereClause += `n.${item} = "nan",`;
    } else {
      whereClause += `n.${item} = "${itemVal}",`;
    }
  });

  whereClause = whereClause.replace(/(^,)|(,$)/g, "");
  console.log("returnWhere", whereClause);
  return whereClause;
}

async function DeleteProperties() {
  const Planning_Item_ID = $("#txt_Planning_Item_ID").val();
  const name = $("#txt_name").val();
  const query = `MATCH (n:Item_Name {Planning_Item_ID:"${Planning_Item_ID}"}) DETACH DELETE n`;
  const res = await neo4j.update(query);
  console.log("del-query", query);
  console.log("res.status", res);
  if (res.status === 200) {
    $("#alert-modal .modal-body").html("Node deleted succesfully!");
    $("#alert-modal").modal("toggle");

    //ReDraw

    showNodeTypes();
    showAllNodeTypes();
    drawTree();
    CreateAuditLogs(sessionStorage.getItem("userId"), name, "Deleted node");
  }
}

const loadParentNames = async () => {
  const query = `MATCH (n:Planning_Item_Parent_Name) RETURN distinct n.name`;
  const res = await neo4j.get(query);
  res.results[0].data.forEach((item) => {
    $("#txt_add_Planning_Item_Parent_Name").append(
      $("<option />").val(item.row[0]).text(item.row[0])
    );
  });
};

async function AddNode() {
  const name = $("#txt_add_name").val();
  const Rolledup_Budget = $("#txt_add_Rolledup_Budget").val();
  const Planning_Item_Owner_User_Name = $(
    "#txt_add_Planning_Item_Owner_User_Name"
  ).val();
  const Allocated_Budget_Currency = $(
    "#txt_add_Allocated_Budget_Currency"
  ).val();
  const Planning_Level_Type = $("#txt_add_Planning_Level_Type").val();
  const Planning_Item_ID = $("#txt_add_Planning_Item_ID").val();
  const Planning_Item_Name = $("#txt_add_Planning_Item_Name").val();
  const Planning_Item_Created_By_User_Name = $(
    "#txt_add_Planning_Item_Created_By_User_Name"
  ).val();
  const Level_3_Planning_Item_Name = $(
    "#txt_add_Level_3_Planning_Item_Name"
  ).val();
  const Team_Size = $("#txt_add_Team_Size").val();
  const Level_4_Planning_Item_Name = $(
    "#txt_add_Level_4_Planning_Item_Name"
  ).val();
  const Level_2_Planning_Item_Name = $(
    "#txt_add_Level_2_Planning_Item_Name"
  ).val();
  const Level_1_Planning_Item_Name = $(
    "#txt_add_Level_1_Planning_Item_Name"
  ).val();
  const Currency_cd = $("#txt_add_Currency_cd").val();
  const Planning_Item_Type = $("#txt_add_Planning_Item_Type").val();
  const Planning_Item_Last_Modified_By_User_Name =
    sessionStorage.getItem("userId");
  const Plan_Start_Date = $("#txt_add_Plan_Start_Date").val();
  const Planning_Item_Number = $("#txt_add_Planning_Item_Number").val();
  const Planning_Item_Parent_Name = $(
    "#txt_add_Planning_Item_Parent_Name"
  ).val();
  const Total_Invoiced = $("#txt_add_Total_Invoiced").val();
  const Hierarchy_Definition_ID = $("#txt_add_Hierarchy_Definition_ID").val();
  const Task_Phase = $("#txt_add_Task_Phase").val();
  
  const Planning_Level_Number = $("#txt_add_Planning_Level_Number").val();
  const Task_Cost = $("#txt_add_Task_Cost").val();
  const Hierarchy_Definition_Node_ID = $(
    "#txt_add_Hierarchy_Definition_Node_ID"
  ).val();
  const Total_Committed = $("#txt_add_Total_Committed").val();

  const Total_Expenses = $("#txt_add_Total_Expenses").val();
  const Reserved_Budget = $("#txt_add_Reserved_Budget").val();
  const Task_Status = $("#txt_add_Task_Status").val();

  const Available_Budget = $("#txt_add_Available_Budget").val();
  const Planning_Item_Description = $(
    "#txt_add_Planning_Item_Description"
  ).val();
  const Total_Budget = $("#txt_add_Total_Budget").val();
  const Allocated_Budget = $("#txt_add_Allocated_Budget").val();
  const Planning_Item_Path = $("#txt_add_Planning_Item_Path").val();

  if (!name) {
    alert("Please enter name");
    return;
  }

  if (!Planning_Item_Parent_Name) {
    alert("please select parent");
    return;
  }

  //Create Node
  const create_query = `CREATE (n:Item_Name {name : '${name}',
  Rolledup_Budget : '${Rolledup_Budget}',
  Planning_Item_Owner_User_Name : '${Planning_Item_Owner_User_Name}',
  Allocated_Budget_Currency : '${Allocated_Budget_Currency}',
  Planning_Level_Type : '${Planning_Level_Type}',
  Planning_Item_ID : '${Planning_Item_ID}',
  Planning_Item_Name : '${Planning_Item_Name}',
  Planning_Item_Created_By_User_Name : '${Planning_Item_Created_By_User_Name}',
  Level_3_Planning_Item_Name : '${Level_3_Planning_Item_Name}',
  Team_Size : '${Team_Size}',
  Level_4_Planning_Item_Name : '${Level_4_Planning_Item_Name}',
  Level_2_Planning_Item_Name : '${Level_2_Planning_Item_Name}',
  Level_1_Planning_Item_Name : '${Level_1_Planning_Item_Name}',
  Currency_cd : '${Currency_cd}',
  Planning_Item_Type : '${Planning_Item_Type}',
  Planning_Item_Last_Modified_By_User_Name : '${Planning_Item_Last_Modified_By_User_Name}',
  Plan_Start_Date : '${Plan_Start_Date}',
  Planning_Item_Number : '${Planning_Item_Number}',
  Planning_Item_Parent_Name : '${Planning_Item_Parent_Name}',
  Total_Invoiced : '${Total_Invoiced}',
  Hierarchy_Definition_ID : '${Hierarchy_Definition_ID}',
  Task_Phase : '${Task_Phase}',
  
  Planning_Level_Number : '${Planning_Level_Number}',
  Task_Cost : '${Task_Cost}',
  Hierarchy_Definition_Node_ID : '${Hierarchy_Definition_Node_ID}',
  Total_Committed : '${Total_Committed}',
  
  Total_Expenses : '${Total_Expenses}',
  Reserved_Budget : '${Reserved_Budget}',
  Task_Status : '${Task_Status}',  
  Available_Budget : '${Available_Budget}',
  Planning_Item_Description : '${Planning_Item_Description}',
  Total_Budget : '${Total_Budget}',
  Allocated_Budget : '${Allocated_Budget}',
  Planning_Item_Path : '${Planning_Item_Path}'
  }
    ) RETURN n`;

  const relationship_query = `MATCH (i:Item_Name),(p:Planning_Item_Parent_Name) where i.Planning_Item_ID='${Planning_Item_ID}' and p.name='${Planning_Item_Parent_Name}' create (p)-[:Child]->(i)`;
  const res = await neo4j.update(create_query);

  if (res.data.errors.length) {
    console.log("Failed to create Node");
    return;
  }

  const rel_res = await neo4j.update(relationship_query);

  if (rel_res.data.errors.length) {
    console.log("Failed to create relationship");
    return;
  }

  console.log("relationship created");
  $("#add-modal").modal("toggle");
  $("#alert-modal .modal-body").html("Node added succesfully");
  $("#alert-modal").modal("toggle");
  showNodeTypes();
  showAllNodeTypes();
  drawTree();
  clearAllTextBox();
  CreateAuditLogs(sessionStorage.getItem("userId"), name, "Created Node");
}

function clearAllTextBox() {
  $("#add-modal")
    .find("input")
    .each(function () {
      console.log("clear", $(this).val());
      $(this).val("");
    });
}

$("#btn-close").on("click", () => {
  clearAllTextBox();
});
